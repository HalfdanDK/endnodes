const Fs = require('fs-extra');
const Request = require('request');

const ConfigHelper = require('./../helpers/config');
const ResponseHelper = require('./../helpers/responses');

const Config = new ConfigHelper();

class MinecraftPluginInstallerController {
    constructor(auth, req, res) {
        this.req = req;
        this.res = res;

        this.auth = auth;
        this.responses = new ResponseHelper(req, res);
    }

    downloadPlugin() {
        this.auth.allowed('s:plugins', (allowedErr, isAllowed) => {
            if (allowedErr || !isAllowed) return;

            if ("id" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing id argument"});

            const id = this.req.params["id"];

            const uuid = this.auth.server().uuid;
            const auth = this.auth;
            const res = this.res;

            Fs.access(Config.get('sftp.path').toString() + '/' + uuid + '/plugins', error => {
                if (!error) {
                    Request({
                        method: 'GET',
                        url: 'https://api.spiget.org/v2/resources/' + id + '/download',
                        followAllRedirects: true,
                        headers: {
                            'Connection': 'keep-alive',
                            'User-Agent': 'pterodactyl-plugin-manager/1.0'
                        },
                    })
                        .on('response', function (response) {
                            const contentDisposition = response.headers['content-disposition'];
                            const match = contentDisposition && contentDisposition.match(/(filename=|filename\*='')(.*)$/);

                            let filename = match && match[2] || 'default-plugin-name';

                            filename = filename.replace('"', '');
                            filename = filename.replace('"', '');
                            filename = filename.split('#')[0] + '.jar';

                            const file = Fs.createWriteStream(Config.get('sftp.path').toString() + "/" + uuid + "/plugins/" + filename);

                            response.pipe(file);

                            auth.server().fs.chown('/plugins/' + filename, (err) => {
                                return res.send({"success": "true", "name": filename});
                            });
                        })
                        .on('error', (error) => {
                            return res.send({"success": "false", "name": "Plugins folder not exists!"});
                        });
                } else {
                    return res.send({"success": "false", "name": "Plugins folder not exists!"});
                }
            });
        });
    }

    deletePlugin() {
        this.auth.allowed('s:plugins', (allowedErr, isAllowed) => {
            if (allowedErr || !isAllowed) return;

            if ("name" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing name argument"});

            const name = this.req.params["name"];

            const uuid = this.auth.server().uuid;
            const res = this.res;

            this.auth.server().fs.rm('/plugins/' + name, (err) => {
                res.send({"success": "true"});
            });
        });
    }
}

module.exports = MinecraftPluginInstallerController;
